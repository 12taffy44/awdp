import React from 'react';
import './App.css';

function App() {
  return (
    <div className="app">
      {/* 侧边栏 */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="logo-section">
            <div className="logo-icon">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <path d="M16 2L28 8V16C28 24 22 28 16 30C10 28 4 24 4 16V8L16 2Z" fill="url(#gradient1)" />
                <path d="M11 14L14 17L21 10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <defs>
                  <linearGradient id="gradient1" x1="4" y1="2" x2="28" y2="30">
                    <stop offset="0%" stopColor="#3b82f6" />
                    <stop offset="100%" stopColor="#8b5cf6" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <div className="logo-text">
              <h1>CyberStrikeAI</h1>
              <span>v3.35</span>
            </div>
          </div>
          <button className="collapse-btn">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        <nav className="nav">
          <div className="nav-section">
            <div className="nav-item active">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <rect x="2" y="2" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/>
                  <rect x="11" y="2" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/>
                  <rect x="2" y="11" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/>
                  <rect x="11" y="11" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.5"/>
                </svg>
              </span>
              <span className="nav-text">仪表盘</span>
            </div>

            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M3 4C3 3.44772 3.44772 3 4 3H16C16.5523 3 17 3.44772 17 4V13C17 13.5523 16.5523 14 16 14H7L3 18V4Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
                </svg>
              </span>
              <span className="nav-text">对话</span>
            </div>

            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M3.5 10L8.5 15L16.5 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <rect x="2" y="2" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="1.5"/>
                </svg>
              </span>
              <span className="nav-text">任务管理</span>
            </div>

            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M10 12C12.2091 12 14 10.2091 14 8C14 5.79086 12.2091 4 10 4C7.79086 4 6 5.79086 6 8C6 10.2091 7.79086 12 10 12Z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M4 18C4 14.6863 6.68629 12 10 12C13.3137 12 16 14.6863 16 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </span>
              <span className="nav-text">漏洞管理</span>
            </div>

            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M9.5 3H5C3.89543 3 3 3.89543 3 5V15C3 16.1046 3.89543 17 5 17H15C16.1046 17 17 16.1046 17 15V10.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M12 3H17V8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M8.5 11.5L17 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </span>
              <span className="nav-text">MCP</span>
              <span className="nav-badge">3</span>
            </div>
          </div>

          <div className="nav-divider"></div>

          <div className="nav-section">
            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M3 6C3 4.89543 3.89543 4 5 4H15C16.1046 4 17 4.89543 17 6V14C17 15.1046 16.1046 16 15 16H5C3.89543 16 3 15.1046 3 14V6Z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M7 8H13M7 12H11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </span>
              <span className="nav-text">知识</span>
              <span className="nav-arrow">›</span>
            </div>

            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M4 4H16V10H4V4Z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M7 16H13M10 13V19" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </span>
              <span className="nav-text">Skills</span>
              <span className="nav-arrow">›</span>
            </div>

            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M10 12C12.2091 12 14 10.2091 14 8C14 5.79086 12.2091 4 10 4C7.79086 4 6 5.79086 6 8C6 10.2091 7.79086 12 10 12Z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M3 18C3 14.134 6.13401 11 10 11C13.866 11 17 14.134 17 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </span>
              <span className="nav-text">角色</span>
              <span className="nav-arrow">›</span>
            </div>
          </div>

          <div className="nav-divider"></div>

          <div className="nav-section">
            <div className="nav-item">
              <span className="nav-icon">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M10 11.5C10.8284 11.5 11.5 10.8284 11.5 10C11.5 9.17157 10.8284 8.5 10 8.5C9.17157 8.5 8.5 9.17157 8.5 10C8.5 10.8284 9.17157 11.5 10 11.5Z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M10 6.5V7.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M10 12.5V13.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M6.5 10H7.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M12.5 10H13.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </span>
              <span className="nav-text">系统设置</span>
            </div>
          </div>
        </nav>
      </aside>

      {/* 主内容 */}
      <main className="main">
        {/* 顶部栏 */}
        <header className="top-bar">
          <div className="top-bar-left">
            <h1 className="page-title">仪表盘</h1>
          </div>
          <div className="top-bar-right">
            <a href="#" className="top-link">
              API 文档
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M4 12L12 4M12 4H6M12 4V10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </a>
            <div className="user-avatar-small">A</div>
            <button className="refresh-button">
              <span>刷新</span>
            </button>
          </div>
        </header>

        {/* 统计卡片 */}
        <div className="stats-grid">
          <div className="stat-card primary">
            <div className="stat-content">
              <div className="stat-value">0</div>
              <div className="stat-label">运行中任务</div>
            </div>
          </div>

          <div className="stat-card warning">
            <div className="stat-content">
              <div className="stat-value">5</div>
              <div className="stat-label">漏洞总数</div>
            </div>
          </div>

          <div className="stat-card success">
            <div className="stat-content">
              <div className="stat-value">29</div>
              <div className="stat-label">工具调用次数</div>
            </div>
          </div>

          <div className="stat-card success">
            <div className="stat-content">
              <div className="stat-value">100%</div>
              <div className="stat-label">工具执行成功率</div>
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="main-content">
          {/* 左侧内容 */}
          <div className="content-left">
            {/* 漏洞分布 */}
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">漏洞严重程度分布</h3>
              </div>
              <div className="card-body">
                <div className="severity-chart">
                  <div className="severity-bar">
                    <div className="severity-segment critical" style={{ width: '20%' }}></div>
                    <div className="severity-segment high" style={{ width: '20%' }}></div>
                    <div className="severity-segment medium" style={{ width: '20%' }}></div>
                    <div className="severity-segment low" style={{ width: '20%' }}></div>
                    <div className="severity-segment info" style={{ width: '20%' }}></div>
                  </div>
                  <div className="severity-labels">
                    <div className="severity-label">
                      <span className="dot critical"></span>
                      <span>严重 1</span>
                    </div>
                    <div className="severity-label">
                      <span className="dot high"></span>
                      <span>高危 1</span>
                    </div>
                    <div className="severity-label">
                      <span className="dot medium"></span>
                      <span>中危 1</span>
                    </div>
                    <div className="severity-label">
                      <span className="dot low"></span>
                      <span>低危 1</span>
                    </div>
                    <div className="severity-label">
                      <span className="dot info"></span>
                      <span>信息 1</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 运行概览 */}
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">运行概览</h3>
              </div>
              <div className="card-body">
                <div className="overview-list">
                  <div className="overview-item">
                    <div className="overview-header">
                      <div className="overview-icon task-icon">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                          <rect x="2" y="2" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.3"/>
                          <rect x="10" y="2" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.3"/>
                          <rect x="2" y="10" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.3"/>
                          <rect x="10" y="10" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.3"/>
                        </svg>
                      </div>
                      <div className="overview-info">
                        <div className="overview-title">批量任务队列</div>
                        <div className="overview-stats">
                          <div className="stat-item">
                            <span className="dot pending"></span>
                            <span>1 待执行</span>
                          </div>
                          <div className="stat-item">
                            <span className="dot running"></span>
                            <span>0 执行中</span>
                          </div>
                          <div className="stat-item">
                            <span className="dot completed"></span>
                            <span>1 已完成</span>
                          </div>
                        </div>
                        <div className="progress-track">
                          <div className="progress-bar pending" style={{ width: '50%' }}></div>
                          <div className="progress-bar completed" style={{ width: '50%', left: '50%' }}></div>
                        </div>
                      </div>
                      <div className="overview-badge">共 2 个</div>
                    </div>
                  </div>

                  <div className="overview-item">
                    <div className="overview-header">
                      <div className="overview-icon tool-icon">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                          <path d="M12 2L14 4L10.5 7.5L12 9L9 12L7.5 10.5L4 14L2 12L5.5 8.5L4 7L7 4L8.5 5.5L12 2Z" fill="currentColor" opacity="0.3"/>
                        </svg>
                      </div>
                      <div className="overview-info">
                        <div className="overview-title">工具调用</div>
                        <div className="overview-value">
                          <strong>29</strong> 次调用
                          <span className="separator">·</span>
                          <strong>23</strong> 个工具
                        </div>
                      </div>
                      <div className="overview-tag success">成功率: 100%</div>
                    </div>
                  </div>

                  <div className="overview-item">
                    <div className="overview-header">
                      <div className="overview-icon knowledge-icon">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                          <path d="M3 4.5C3 3.67157 3.67157 3 4.5 3H13.5C14.3284 3 15 3.67157 15 4.5V13.5C15 14.3284 14.3284 15 13.5 15H4.5C3.67157 15 3 14.3284 3 13.5V4.5Z" fill="currentColor" opacity="0.3"/>
                          <path d="M6 6H12M6 9H10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      </div>
                      <div className="overview-info">
                        <div className="overview-title">知识</div>
                        <div className="overview-value">
                          <strong>11</strong> 项知识
                          <span className="separator">·</span>
                          <strong>2</strong> 个分类
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="overview-item">
                    <div className="overview-header">
                      <div className="overview-icon skill-icon">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                          <path d="M4 4H14V10H4V4Z" fill="currentColor" opacity="0.3"/>
                          <path d="M7 14H11M9 12V16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      </div>
                      <div className="overview-info">
                        <div className="overview-title">Skills</div>
                        <div className="overview-value">
                          <strong>0</strong> 次调用
                          <span className="separator">·</span>
                          <strong>22</strong> 个 Skill
                        </div>
                      </div>
                      <div className="overview-tag">待使用</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 快速入口 */}
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">快捷入口</h3>
              </div>
              <div className="card-body">
                <div className="quick-actions">
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M3 4C3 3.44772 3.44772 3 4 3H16C16.5523 3 17 3.44772 17 4V13C17 13.5523 16.5523 14 16 14H7L3 18V4Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
                    </svg>
                    <span>对话</span>
                  </button>
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M3.5 10L8.5 15L16.5 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <rect x="2" y="2" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="1.5"/>
                    </svg>
                    <span>任务管理</span>
                  </button>
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M10 12C12.2091 12 14 10.2091 14 8C14 5.79086 12.2091 4 10 4C7.79086 4 6 5.79086 6 8C6 10.2091 7.79086 12 10 12Z" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M4 18C4 14.6863 6.68629 12 10 12C13.3137 12 16 14.6863 16 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <span>漏洞管理</span>
                  </button>
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M9.5 3H5C3.89543 3 3 3.89543 3 5V15C3 16.1046 3.89543 17 5 17H15C16.1046 17 17 16.1046 17 15V10.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                      <path d="M12 3H17V8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M8.5 11.5L17 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <span>MCP 管理</span>
                  </button>
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M3 6C3 4.89543 3.89543 4 5 4H15C16.1046 4 17 4.89543 17 6V14C17 15.1046 16.1046 16 15 16H5C3.89543 16 3 15.1046 3 14V6Z" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M7 8H13M7 12H11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <span>知识管理</span>
                  </button>
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M4 4H16V10H4V4Z" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M7 16H13M10 13V19" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <span>Skills 管理</span>
                  </button>
                  <button className="quick-btn">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M10 12C12.2091 12 14 10.2091 14 8C14 5.79086 12.2091 4 10 4C7.79086 4 6 5.79086 6 8C6 10.2091 7.79086 12 10 12Z" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M3 18C3 14.134 6.13401 11 10 11C13.866 11 17 14.134 17 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <span>角色管理</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 右侧内容 */}
          <div className="content-right">
            {/* 工具执行次数 */}
            <div className="card tool-card">
              <div className="card-header">
                <h3 className="card-title">工具执行次数</h3>
              </div>
              <div className="card-body">
                <div className="tool-list">
                  <div className="tool-item">
                    <span className="tool-name">record_url</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '100%', backgroundColor: '#6366f1' }}></div>
                    </div>
                    <span className="tool-count">5</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">executor-py</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '40%', backgroundColor: '#22c55e' }}></div>
                    </div>
                    <span className="tool-count">2</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">burpsuite</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#eab308' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">cat</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#f87171' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">checksec</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#fb7185' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">create-file</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#60a5fa' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">delete-file</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#38bdf8' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">dirlist</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#22d3d1' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">ffuf</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#4ade80' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">exiftool</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#a78bfa' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">hash-ident</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#818cf8' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">hydra</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#6366f1' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">install-py</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#4f46e5' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">jwt-analyzer</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#f472b6' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">masscan</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#fbbf24' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">msfvenom</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#a5b4fc' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">metasploit</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#c7d2fe' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">nmap</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#fed7aa' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">nikto</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#fecdd3' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">sqlmap</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#7c3aed' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">strings</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#4c1d95' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                  <div className="tool-item">
                    <span className="tool-name">trivy</span>
                    <div className="tool-progress">
                      <div className="tool-bar" style={{ width: '20%', backgroundColor: '#4ade80' }}></div>
                    </div>
                    <span className="tool-count">1</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 底部横幅 */}
        <div className="cta-banner">
          <div className="cta-content">
            <div className="cta-icon">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <rect x="4" y="6" width="24" height="20" rx="4" fill="white" fillOpacity="0.2"/>
                <path d="M11 12L14 15L21 10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="cta-text">
              <h3>开始你的安全之旅</h3>
              <p>在对话中描述目标，AI 将协助执行扫描与漏洞分析</p>
            </div>
            <button className="cta-button">
              前往对话
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M6 4L10 8L6 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;